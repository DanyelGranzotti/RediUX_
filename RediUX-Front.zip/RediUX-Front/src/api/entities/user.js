import * as httpRequests from "../common/api_requests";
import { URLS } from "../common/endpoints";

const fetchLogin = async (obj) => {
  try {
    const res = await httpRequests.postMethod(URLS.USER + "/signin", obj, {
      credentials: "include",
    });
    const body = res.data;
    if (body) {
      // Aqui, o token é gerenciado no cookie pelo backend.
      return body;
    }
  } catch (error) {
    return error;
  }
};

const fetchRegister = async (obj) => {
  try {
    const res = await httpRequests.postMethod(URLS.USER + "/signup", obj);
    const body = res.data;
    if (body) {
      localStorage.setItem("token", body.token);
      localStorage.setItem("userId", body.user.id);
      localStorage.setItem("userEmail", body.user.email);

      return body;
    }
  } catch (error) {
    return error;
  }
};

const fetchLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("userId");
  localStorage.removeItem("userEmail");
  window.location.href = "/";
};

export { fetchLogin, fetchLogout };

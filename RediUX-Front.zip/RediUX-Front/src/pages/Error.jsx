const Error = () => {
  return (
    <main className="container flex justify-center items-center h-screen">
      Error
    </main>
  );
};

export default Error;

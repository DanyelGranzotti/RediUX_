const NotFound = () => {
  return (
    <main className="container flex justify-center items-center h-screen">
      NotFound
    </main>
  );
};

export default NotFound;

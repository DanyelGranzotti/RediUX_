const Content = () => {
  return (
    <main className="container flex justify-center items-center h-screen">
      Content
    </main>
  );
};

export default Content;
